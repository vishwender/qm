import React, {Component} from "react";
import {Link} from "react-router-dom";
import axios from 'axios';

class Login extends Component{

    state = {
        email: '',
        password: ''
    };

    handleInput = (e) =>{
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    login = async (e) =>{
        e.preventDefault();
        axios.get('http://backend-api.lndo.site/sanctum/csrf-cookie').then(async () =>{
            axios.post('http://backend-api.lndo.site/api/login', this.state).then((response) => {
                console.log(response.data.status);
                navigate('/Dashboard');
            });
        });
    };

    render(){
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="card">
                            <div className="card-header">
                                <h4>
                                    Login
                                    <Link to={"sign-up"} className="btn btn-primary btn-sm float-end">Sign Up</Link>
                                </h4>
                            </div>
                            <div className="card-body">
                                <form onSubmit={this.login}>
                                    <div className="form-group mb-3">
                                        <label>email</label>
                                        <input type="email" name="email" onChange={this.handleInput} value={this.state.username} className="form-control" required/>
                                    </div>
                                    <div className="form-group mb-3">
                                        <label>password</label>
                                        <input type="password" name="password" onChange={this.handleInput} value={this.state.password} className="form-control" required/>
                                    </div>
                                    <div className="form-group mb-3">
                                        <button type="submit" className="btn btn-primary">Login</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Login;