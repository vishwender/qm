import React, {Component} from "react";

class Dashboard extends Component{

render(){
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-header">
                            <h4>
                                Sign Up
                                <Link to={"/"} className="btn btn-primary btn-sm float-end">Back</Link>
                            </h4>
                        </div>
                        <div className="card-body">
                            <form onSubmit={this.signup}>
                                <div className="form-group mb-3">
                                    <label>username</label>
                                    <input type="text" name="username" onChange={this.handleInput} value={this.state.username} className="form-control" required/>
                                </div>
                                <div className="form-group mb-3">
                                    <label>email</label>
                                    <input type="text" name="email" onChange={this.handleInput} value={this.state.email} className="form-control" required/>
                                </div>
                                <div className="form-group mb-3">
                                    <label>password</label>
                                    <input type="password" name="password" onChange={this.handleInput} value={this.state.password} className="form-control" required/>
                                </div>
                                <div className="form-group mb-3">
                                    <button type="submit" className="btn btn-primary">Sign up</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
}

export default Signup;